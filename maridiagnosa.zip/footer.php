<footer class="overlay">
  <div class="container">
    <div class="row justify-content-between">
      <div class="col-lg-4 mb-4">
        <img src="images/nav-logo.png" alt="" />
      </div>
    </div>
    <hr class="my-4" />
    <div class="row justify-content-between">
      <div class="col-lg-4 mb-3">
        <small>KEMENTERIAN KOMUNIKASI DAN INFORMATIKA. Jalan Medan Merdeka Barat No.9, Jakarta Pusat, 10110</small>
      </div>
      <div class="col-lg-4 text-lg-end">
        <small>©PeduliLindungi. All rights reserved.</small>
      </div>
    </div>
  </div>
</footer>

